 

unrelated<-function(snp=1000,freq=0.2,min=0.05,max=0.5){
#snp=1000;freq=0.2;min=0.05;max=0.5
if(is.null(freq))
  p<-runif(snp,min,max)
else 
  p<-sample(freq,snp,replace=T)
prob<-t(matrix(c(p,1-p),nrow=length(p)))
hap<-apply(prob,2,sample,x=c(1,0),size=1,replace=T)
return(hap)
}

sim_chr<-function(snp=1000,freq=0.2,min=0.05,max=0.5,F=0,a=0,number_per_cm=1){
hap1<-unrelated(snp,freq,min,max)
hap2<-unrelated(snp,freq,min,max)

pos<-as.integer(rnorm(snp,mean=1000000,sd=100000))/number_per_cm
cumpos<-cumsum(as.numeric(pos))

if(a!=0){
IB_tract<-rep(FALSE,snp)
IB<-sample(c(TRUE,FALSE),1,replace=T,prob=c(F,1-F))
pos<-pos/1000000
num=0
change=NULL
if(IB)
  num=1
for(tal in 1:snp){
  if(IB){
    IB<-sample(c(FALSE,TRUE),1,replace=T,prob=c((1-F)*(1-exp(-a*pos[tal])),1-(F-1)*(1-exp(-a*pos[tal]))))
    if(!IB)
      change[num*2]<-cumpos[tal]
  }
  else{
    IB<-sample(c(TRUE,FALSE),1,replace=T,prob=c((F)*(1-exp(-a*pos[tal])),1-(F)*(1-exp(-a*pos[tal]))))
    if(IB){
      num=num+1
      change[num*2-1]<-cumpos[tal]
    }
  }

  if(IB)
    IB_tract[tal]=T
}
}
else
  IB_tract<-sample(c(TRUE,FALSE),snp,replace=T,prob=c(F,1-F))

hap2[IB_tract]<-hap1[IB_tract]

geno<-hap1+hap2

obs<-list(geno=geno,IB_tract=IB_tract,F=F,a=a,freq=freq,number_per_cm=number_per_cm,min=min,max=max,snp=snp,pos=cumpos,num=num,change=change)

class(obs)="sim_chr"
return(obs)
}


plot.sim_chr<-function(x,col=c(4,2),min=NULL,max=NULL){

if(is.null(min))
min=min(x$pos)
if(is.null(max))
max=max(x$pos)

keep<-x$pos>=min&x$pos<=max

col<-ifelse(x$IB_tract,col[1],col[2])
IB<-ifelse(x$IB_tract,2,1)
plot(x$pos[keep],IB[keep],col=col[keep],xlab="position",ylab="IBD status",ylim=c(0,3),pch="|")

cat("F hat= ",mean(x$IB_tract),"\n")
cat("number of imbreeding tracts ",x$num,"\n")
cat("average imbreedning tract=",sum(x$IB_tract)/(x$num*x$number_per_cm) ," cm \n")


}




#sim<-sim_chr(10000,F=1/16,a=0.063);plot(sim);



