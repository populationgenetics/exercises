eigenstrat<-function(geno,maxMis=0,minMaf=0.01,maxMisInd=0.05){                 
## geno: snp x ind matrix of genotypes \in 0,1,2
##maxMis maximum allowed missing genotypes for a site

  nMis <- rowSums(is.na(geno))
  misInd <- colMeans(is.na(geno))
  keepInd<-maxMisInd>misInd
  if(sum(keepInd)<10)
      return("not enought individuals left")
  geno<-geno[,keepInd]
  freq <- rowMeans(geno,na.rm=T)/2               # get allele frequency 
  keep <- freq>minMaf&freq<(1-minMaf) & nMis<=maxMis         # remove sites with non-polymorphic data

  if(sum(keep)<100)
      return("not enought sites left")
  freq<-freq[keep]
  geno<-geno[keep,]
  snp<-nrow(geno)                           #number of snps used in analysis
  ind<-ncol(geno)                           #number of individuals used in analuysis
  M <- (geno-freq*2)/sqrt(freq*(1-freq))       #normalize the genotype matrix
  M[is.na(M)]<-0
  X<-t(M)%*%M                               #get the (almost) covariance matrix
  X<-X/(sum(diag(X))/(snp-1))
  E<-eigen(X)

  mu<-(sqrt(snp-1)+sqrt(ind))^2/snp         #for testing significance (assuming no LD!)
  sigma<-(sqrt(snp-1)+sqrt(ind))/snp*(1/sqrt(snp-1)+1/sqrt(ind))^(1/3)
  E$TW<-(E$values[1]*ind/sum(E$values)-mu)/sigma
  E$mu<-mu
  E$keepInd<-keepInd
  E$sigma<-sigma
  E$nSNP <- nrow(geno)
  E$nInd <- ncol(geno)
  class(E)<-"eigenstrat"
  E
}
#####################################
#        function to plot an error
###############################################
errorPlot<-function(txt,cex=2,error="Error"){
    plot(0:1,0:1,col="transparent",xlab="",ylab="",axes=F)
    text(0.5,0.5,txt,cex=cex)
    mtext(error,1:4,col="red",cex=2)
}

###############################
#       password function
#################################


pw<-function(x,passWord,type="plot"){


  #  validate(need(x %in% passWord,"must provide password!"))

    
    tex<-"Enter correct password"
    if(type=="plot")
        errorPlot(tex)
    if(type=="matrix")
        matrix(tex,1,1)
    if(type=="text")
        tex
    return(!x$pw%in%passWord)

}

#mkLegned(rownames(res))
################################################
# function for making legend
################################################
mkLegend<-function(ind,indCol,pop,popCol,position="topright",cex=1.5){

    if(!missing(pop) & ! missing(popCol)){
        chosenPop<-unique(pop[ind])
        legend(position,chosenPop,fill=popCol[chosenPop],cex=cex,bg="white")
    }
    else{
        legend(position,ind,fill=indCol[ind],cex=cex,bg="white")
    }

}
