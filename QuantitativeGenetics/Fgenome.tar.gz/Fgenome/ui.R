#  require(rCharts)
#options(RCHART_LIB = 'polycharts')

library(shiny)
  
#inds<-read.table("name.files",as.is=T)

popNames<-"asdf"
outGroup<-"asdf"
colorSc<-c("default","line","rasmus","colorblind6b","anders","large")


# Define UI for dataset viewer application
shinyUI(pageWithSidebar(
 
  # Application title
    headerPanel("IBD popgen course 2016"),
    sidebarPanel( 
 
       

                  #        uiOutput('chooseInd'),
#                         selectInput("qual", "Choose min baseQ min mapQ:",choices = c("none","Q20q30"))
        actionButton("runFgenome", "Run simulation"),
  
        numericInput("F", "F (inbreeding):", 0),
        numericInput("a", "a (non simple inbreeding):", 0),
  selectInput("color", "Choose color scheme:",choices = colorSc),
      
                      
        helpText('hello')
#################shared panel bottom
#      checkboxInput('keepLateDorset', 'include late Dorset'),
#      uiOutput('chooseWholePop'),
#      uiOutput('chooseInd'),
 #     selectInput("color", "Choose color scheme:",choices = colorSc),
 #     downloadButton('downloadData', 'Download result table'), 
 #     helpText(""),
 #     helpText("Save plot "),
  #    checkboxInput('pdf', 'save pdf'),
  #    numericInput("h", "height of plot:", 8),
   #   numericInput("w", "width of plot", 16),
   #   checkboxInput('leg', 'include legend',value=TRUE),
     # helpText('Rember to choose "save pdf" if you want a pdf:', a("pdf link", href="http://popgen.dk/albrecht/open/tmp/tmp.pdf"))
#      textInput("main", "plot title:", "")
   
  ),
   
  # Show a summary of the dataset and an HTML table with the requested
  # number of observations
 

   
  mainPanel(

      tabsetPanel(
          #D stat
          tabPanel("sim F genome",h3("Autosomes"),plotOutput("simFgenome",height="7in"))
      #    tabPanel("F site", value=1,h3("moment estimator"),tableOutput("momentF"))
           
        #  tabPanel("Barplot Plot", value=1,h3("Barplot of individuals"),plotOutput("errPlot",height="4.5in"),h2("bam files"), tableOutput("bamFiles"))
          
#          tabPanel("Dstat Plot", value=1,h3("The chosen tree"),plotOutput("treePlot",height="8.5in"),h4("Tests of similar trees"),plotOutput("treePlotMulti",height="16in")),
        #  tabPanel("Dstat Details", value=1,h2("Details of the test"), tableOutput("info")),
        #  tabPanel("Dstat Conclusion", value=1, verbatimTextOutput("summary")),
          #F3 
        #  tabPanel("f3 plot", value=2,h2("F3 statistics"),h3("The chosen tree"),plotOutput("f3Plot",height="2.5in"),h4("Tests of similar trees"),plotOutput("f3PlotMulti",height="16in")),
        #  tabPanel("f3 details", value=2,h2("Details of the test"), tableOutput("infoF3")),
          # treeMix
        #  tabPanel("treeMix plot", value=3,h2("press \"run treeMix\" to run analysis- under develupment"),plotOutput("treeMixPlot",height="10in")),
        #  tabPanel("Details treemix", value=3,h2("Details of the test")),

          #PCA
        #  tabPanel("PCA meta", value=5,h2("press \"run PCA\" to run analysis"),plotOutput("pcaPlot",height="10in")),
        #  tabPanel("PCA standard", value=6,h2("Standard PCA.  press \"run PCA\" to run analysis"),plotOutput("pcaPlotStand",height="10in"))
     

       
          )
    
 
  ) 
))
