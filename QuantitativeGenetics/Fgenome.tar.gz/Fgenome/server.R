errorPlot <- 
function(txt,cex=2,error="Error"){
   
    plot(0:1,0:1,col="transparent",xlab="",ylab="",axes=F)
    text(0.5,0.5,txt,cex=cex)

    mtext(error,1:4,col="red",cex=2)
    
}

actionFgenome<-0
actionRgenome<-0
calculate.a.IBD<-function(F,phi=0.013){
  
    ma<-1-log(F)/log(2)
    mb=0 
  

    m<-ma+mb
    a<--m*log(1-phi)
#cat("m=",m," ma=",ma," mb=",mb," a=",a," k0=",k0," k1=",k1," k2=",k2,"\n")
  return(a)
}


#source("http://popgen.dk/albrecht/open/online.R")
source("IB_sim.R")
library(shiny)
chrLen <-read.table("hg19NoChr.fa.fai",as.is=T)[1:22,]
chrLen <- chrLen[order(as.integer(chrLen[,1])),]
 

##source("/home/albrecht/df3/df3Fun.R")
#source("/home/albrecht/Rfun/treeMix.R")
#library(fastmatch,lib.loc="/home/albrecht/R/x86_64-pc-linux-gnu-library/3.0")
#source("/home/albrecht/Rfun/NGSpca.R")
#source("/home/albrecht/Rfun/shiny.R")

#########################################3

######################################################################
#      Shiny stuff
#      only the stuff above should be modified
#
##############################################################

        
   
   
  
shinyServer(function(input, output) {

   
    
############################################################
##           
############################################################

    output$errPlot <- renderPlot( {

        if(pw(input,passWord))
            return()
        
        ind<-input$chooseInd
        
        if(length(ind)==actionFgenome){
            errorPlot("choose individuals")
            return()
        }
        
        colorAnd(input$color)
        
        el<-errList
        if(input$qual=="Q20q30")
            el<-errListQ
        mat<-do.call(rbind,lapply(el[ind],function(x) x$typeErr))
        over<-do.call(rbind,lapply(el[ind],function(x) x$overallErr))
        
        res<-cbind(mat,over/100)
        names(res)[13]<-"overall"
        write.table(res,file="/home/albrecht/public/albrecht/shiny/tmp/tmp.dat")

        if(input$pdf)
            pdf("/home/albrecht/public/albrecht/shiny/tmp/tmp.pdf",he=input$h,w=input$w)
        
        
        
        if(input$leg)
            barplot(mat,beside=T,col=1:nrow(mat),legend=paste(ind,round(over,2),"%"),args.legend=list(x="top",bty="n"),ylab="Error rates",xlab="Error types")
        else
            barplot(mat,beside=T,col=1:nrow(mat),ylab="Error rates",xlab="Error types")
      
        if(input$pdf){
            dev.off()
            plot(0:1,0:1,col="transparent",main="pdf: http://popgen.dk/albrecht/open/tmp/tmp.pdf? ")
        }

        
    })
#########################3
    output$bamFiles <- renderTable( {
        if(pw(input,passWord,type="text"))
            return()
        
        ind<-input$chooseInd
        
        if(length(ind)==0){
            mat<-matrix("choose individuals",1,1)
            return(mat)
        }
        bn<-bamNam
        names(bn)<-noNamesNames
        #names(noNames)
        #names(bn)<-sub(" ","",names(bn))
        mat <-cbind(ind,bamFile=bn[ind])
        rownames(mat)<-NULL
        return(mat)

    }) 
#######################################
    output$downloadData <- downloadHandler( 
        filename = function() { 'out.txt' },
        content = function(file) {
            dat<-read.table("/home/albrecht/public/albrecht/shiny/tmp/tmp.dat")
            write.table(dat, file,sep="\t")
        }
        )

################# moment F
    output$momentF <- renderTable( {


        f<-input$f
        aa <- input$aa
        Aa <- input$Aa
        AA <- input$AA
        if(any(is.na(c(f,aa,Aa,AA)))){
            mat <- matrix("Fill in aa,Aa,AA and frequency",1,1)
            return(mat)
        }
        N<-aa+Aa+AA
        Eaa <- f^2*N
        EAa <- f*(1-f)*2*N
        EAA <- (1-f)^2*N
        F <- (EAa - Aa)/EAa
        mat <- matrix(c(aa,Aa,AA,Eaa,EAa,EAA,F),nrow=1)
        colnames(mat) <- c("aa","Aa","AA","Eaa","EAa","EAA","F")
        rownames(mat)<-"moment"
        return(mat)

        
    })
############################# sim F genomes
     output$simFgenome <- renderPlot( {

         
         if (input$runFgenome[1] <= 0 | is.null(input$runFgenome)){
             errorPlot("press run simulation")
             return()
         }
         isolate({

             phi<-0.013
             snp=1000
             F <- input$F
             a <- input$a
             if(a<=0|is.na(a)){
                 if(F<0.001)
                     a<-0.04
                 else
                     a<-calculate.a.IBD(F,phi=phi)

             }
             
             len <- 200 # MB
             fun<-function(x){
                 s<- sim_chr(snp,freq=0.2, min=0.5, max=0.95, F=F, a=a, number_per_cm=snp/x/(phi*100) )
                 s$start <- s$pos[diff(s$IB_tract)==1]/(100*phi)
                 s$end <- s$pos[diff(s$IB_tract)==-1]/(100*phi)
                 if(s$IB_tract[1]==TRUE)
                     s$start <- c(0,s$start)
                 if(s$IB_tract[length(s$IB_tract)]==TRUE)
                     s$end <- c(s$end,s$pos[length(s$pos)]/(100*phi))
                 s
             }
             ss <- lapply(chrLen[,2]/1e6,fun)
             pos <- unlist(sapply(ss,function(x)x$pos))/(100*phi)
             state <- unlist(sapply(ss,function(x)x$IB_tract))+1
             

             
             chrl <- unlist(sapply(ss,function(x)length(x$IB_tract)))
             chr <- rep(1:22,chrl)
               if(input$color!="default")
                 ccol <-colorAnd(input$color)[1:2]
             else
                 ccol <- c("darkblue","darkred")

               plot(1,1,col=ccol[state],ylab="chromosomes",xlab="positions (Mb)",pch="|",yaxt='n',main=paste("F for this individaul is ",round(mean(state-1),3)),ylim=c(1,22),xlim=c(0,250))
               rect(rep(0,22),1:22+0.3,chrLen[,2]/1e6,0:21+0.7,col="darkblue")

               for(i in 1:22){
                   n <- length(ss[[i]]$start)
                   rect(ss[[i]]$start/1e6,rep(i+0.3,n),ss[[i]]$end/1e6,rep(i-0.3,n),col="darkred")
               }
               
        
     # plot(pos/1e6,chr,col=ccol[state],ylab="chromosomes",xlab="positions (Mb)",pch="|",yaxt='n',main=paste("F for this individaul is ",round(mean(state-1),3)))
      
           
             text(rep(-5,22),1:22,1:22,xpd=T)

             
             legend("topright",fill=ccol,c("outbreed","Inbreed"))
         #    actionFgenome<<-actionFgenome+1  
         })
       
    }) 
###############
}) 
