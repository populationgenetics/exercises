
colorSc<-c("default","line","rasmus","colorblind6b","anders","large")

actionFgenome<-0
actionRgenome<-0
calculate.a.IBD<-function(F,phi=0.013){
  
    ma<-1-log(F)/log(2)
    mb=0
  

    m<-ma+mb
    a<--m*log(1-phi)
#cat("m=",m," ma=",ma," mb=",mb," a=",a," k0=",k0," k1=",k1," k2=",k2,"\n")
  return(a)
}


source("http://popgen.dk/albrecht/open/online.R")
 
library(shiny)
chrLen <-read.table("functions/hg19NoChr.fa.fai",as.is=T)[1:22,]
chrLen <- chrLen[order(as.integer(chrLen[,1])),]


##source("/home/albrecht/df3/df3Fun.R")
#source("/home/albrecht/Rfun/treeMix.R")
#library(fastmatch,lib.loc="/home/albrecht/R/x86_64-pc-linux-gnu-library/3.0")
#source("/home/albrecht/Rfun/NGSpca.R")
source("shiny.R")

#########################################3
  
sim_chr <- function(snp,freq=0.2, min=0.5, max=0.95, k=k, a=3.854,chrLength){
  CM=1e6

  recom<-function(pos,r=3.854,k,a=NULL){
    if(is.null(a))
      a<-0.1
  
    k0<-k[1]
    k1<-k[2]
    k2<-k[3]
    em<-function(state,t,k0,k1,k2,a){
      IBD01<-(1-exp(-a*t))*k1
      IBD02<-exp(-a*k1*t)*k2/(k1-1)+exp(-a*t)*k1+exp(-a*t)*k0*k1/(k1-1)+k2
      IBD02[IBD02<1e-15]<-0 #underflow problem loesning
      IBD00<-1-IBD01-IBD02
      if(k1==0){
        IBD10<-IBD01
        IBD12<-IBD01
      }
      else{
        IBD10<-IBD01*k0/k1
        IBD12<-IBD01*k2/k1
      }
      IBD11<-1-IBD10-IBD12
      IBD21<-IBD01
      IBD20<-exp(-a*k1*t)*k0/(k1-1)+exp(-a*t)*k1+exp(-a*t)/(k1-1)*k2*k1-(1-k1)*k0/(k1-1)
      IBD20[IBD20<1e-15]<-0 #underflow problem loesning
      IBD22<-1-IBD21-IBD20
      if(state==0)
        prob<-c(IBD00,IBD01,IBD02)
      else if(state==1)
        prob<-c(IBD10,IBD11,IBD12)
      else
        prob<-c(IBD20,IBD21,IBD22)
      return(prob)
    }
  t<-diff(pos)
  state<-sample(0:2,1,prob=c(k0,k1,k2)+0.0000001)
  for(tal in 2:length(pos))  
    state[tal]<-sample(0:2,1,prob=em(state[tal-1],t[tal-1],k0,k1,k2,a)+0.00000001)
  return(state)
  }



  pos <- (1:snp/(snp+1)*chrLength) ## interval between positions
 # pos<-round(pos/number_per_cm,0)
 # pos<-cumsum(pos)
  state=recom(pos/CM,k=k,a=a)

  obs <- list(state=state, k=k, a=a,
              snp=snp, pos=pos)
  class(obs) = "sim_chr"
  return(obs)
}

######################################################################
#      Shiny stuff
#      only the stuff above should be modified
#
##############################################################

        
calculate.a<-function(k0,k1,k2,phi=0.013){
  if(k2==0){
    ma<-1-log(k1)/log(2)
    mb=0
  }
  else{
    xa<-(k1+2*k2+sqrt((k1+2*k2)^2-4*k2))/2
    xb<-k2/xa
    ma<-1-log(xa)/log(2)
    mb<-1-log(xb)/log(2)
  }
  m<-ma+mb
  a<--m*log(1-phi)
#cat("m=",m," ma=",ma," mb=",mb," a=",a," k0=",k0," k1=",k1," k2=",k2,"\n")
  return(a)
}


   
  
shinyServer(function(input, output) {

   
    
############################################################
##           
############################################################

  ## input<-list(k0=0.25,k1=0.5,k2=0.25,a=NA)
############################# sim F genomes
     output$simRgenome <- renderPlot( {

         
         if (input$runFgenome[1] <= 0 | is.null(input$runFgenome)){
             errorPlot("press run simulation")
             return()
         }

         
         isolate({
             
             phi<-0.013
             snp=1000
             k0 <- input$k0
             k1 <- input$k1
             k2 <- input$k2
             k<-c(k0,k1,k2)
             if (sum(k)!=1){
                 errorPlot("The relationshipt coefficients must sum to one")
                 return()
             }
    
             a <- input$a
             if(a<=0|is.na(a)){
                 if(k0>1-0.000000001)
                     a<-0.04
                 else
                     a<-calculate.a(k0,k1,k2,phi=phi)

             }
             if(is.nan(a))
                  validate(  need(FALSE, "Impossible relationship chosen")  )
             len <- 200 # MB
             fun<-function(x)
                 s<- sim_chr(snp,freq=0.2, min=0.5, max=0.95, k=k, a=a,chrLen=x)
             ss <- lapply(chrLen[,2],fun)
             pos <- unlist(sapply(ss,function(x)x$pos))
             state <- unlist(sapply(ss,function(x)x$state))+1
             chrl <- unlist(sapply(ss,function(x)length(x$state)))
             chr <- rep(1:22,chrl)
             if(input$color!="default")
                 ccol <-colorAnd(input$color)[1:3]
             else
                 ccol <- c("darkgreen","darkred","darkblue")
             plot(pos/1e6,chr,col=ccol[state],ylab="chromosomes",xlab="positions (Mb)",pch="|",axes=F,main=paste("Relatedness for this pair of individuals is",paste(c("k0=","K1=","K2="), round(table(factor(state,levels=1:3))/length(state),3),collapse=" ")))
             axis(1)
       #      text(1:2,1:2)
             legend("topright",fill=ccol,c("IBD=0","IBD=1","IBD=2"))
             text(rep(-10,22),1:22,1:22,xpd=T)

         #    actionFgenome<<-actionFgenome+1  
         })
       
    }) 
###############
}) 
