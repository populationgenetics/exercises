popList<-list(
    Africa=c("Yoruba","BantuSouthAfrica","BiakaPygmy","Mandenka","LWK","San","BantuKenya","ASW","YRI","MbutiPygmy"),
    European=c("Basque","Orcadian","CEU","Italian","Sardinian","Russian","TSI","Tuscan","French","Adygei","Ukranians","Estonians","Hungarians"),
    Papuan=c("Papuan","Melanesian"),
    "East Asia"=c("CHB","Tujia","CHD","She","Miao","Japanese","JPT","Yi","Naxi","Henzhen","Oroqen","Dai","Han","Han-NChina","Daur","Lahu","Hezhen","Xibo","Cambodian","Tu"), 
    "Middle East"=c("Bedouin","Mozabite","Palestinian","Druze","Iranian"),
    "south Asia"=c("Brahui","Balochi","Burusho","Kalash","Makrani","Pathan","Sindhi","GIH"),
    "Arctic"=c( "West_Greenlanders","East_Greenlanders","EastGreenland","Saqqaq","Eskimo","WestGreenland","Aleutian"),
    "Naadene"=c("Chipewyan"),
    "north American"=c("Algonquin", "Blackfoot", "Cree", "Ojibwa", "Coast_Miwok", "Luiseno", "Okanagan", "Serrano_or_Gabrielino", "Stswecemc", "Splatsin"),
    "central American"=c("Pima","Yaqui","Tepehuano","Maya1","Maya2","Zapotec2","Mixtec","Mixe","Zapotec1","Kaqchikel","Chorotega"),
    "Chibchan"=c("Purepecha","Kogi","Arhuaco","Maleku","Huetar","Cabecar","Bribri","Teribe","Guaymi","Embera","Waunana"),
    "equa"=c("Wayuu","Guahibo","Palikur","Piapoco","Picuna","Parakana","Jamamadi","Karitiana","Surui","Chane","Guarani","Toba"),
    "Andean"=c("Inga","Quechua","Aymara","Diaguita","Hulliche","Chilote","Chono","Yaghan"),
    gePa=c("Arara","Wichi","Kaingang"),
    "Siberian"=c("Naukan","Ket","Chukchi","Knanty","Selkup","Koryak","Shors","Tundra_Nentsi","Nganasan1","Nganasan2","Dolgan","Evens","Altaian","Tuvinians","Shindhi","Evenki","Yakut","Nivkhs","Buryat","Mongola","Mongolian","Khanty"),
    diag=c("EUseqHigh","EUsamp","EUsamp2","SaqqaqHigh","ClovisHigh","EUseq"),
    misc=c("Ticuna","Yukaghir","MEX","Uygur","Hazara","midDorsetAll"),
    arc=c("lateDorset","Inuk","preDorset","midDorset","prethule","thule","thuleCanadian","thuleGreenland"),
    nor=c("Norton"),
    thu=c("thule","thuleCanadian","thuleGreenland"),
    midD=c("midDorset"),
    lateD=c("lateDorset"),
    saq=c("Inuk"),
    Ancient=c("Malta","Anzick","AG2pmds3","Ajv52","Ajv53","Ajv58","Ajv59","Ajv70","AltaiNea","Bot17","Denosivan","Gok2","Gok4","Gok5","Gok7","Ire8","Labrana","kos24april2014","Kostinki","939","Chinchorro","enoque65merged"),
    Athabascans=c("Apache", "Carrier", "Chilcotin", "Navajo", "Sarcee", "Tlingit", "Chipewyan", "Slavey","Athabascans"),
    isolates=c("Coastal_Tsimshian", "Haida", "Interior_Tsimshian", "Nisgaa")
    )
names(popList) <- sub(" ","_",names(popList))

###################################################3
#       read  SNP chip data
#############################################


library(snpMatrix)
#step 1: change the plinkFilename
#the plink file much a propor plink file with unique familiy IDs/IndivIDUALS ID
plinkFile <- "/pontus/data/anders/modern/snpChip/plink/reich_EBC_full_panel_1stRel_ripan_saqqaqPlus"

pl<-plink(plinkFile)
popInfo<-read.table("/pontus/data/anders/modern/snpChip/mike23jan2015/reich_EBC_full_panel_1stRel_ripan_saqqaq.genotypes.K3_masked.ind",as.is=T)
rownames(popInfo) <- popInfo[,1]
snp<-colnames(pl$pl)
ss<-sapply(names(table(popInfo[,3])),function(x) x%in%unlist(popList))
ss[!ss]
sapply(popList,function(x) x[!x%in%popInfo[,3]])


mergeList<-list(
Carrier=c("athabaskCA12","athabaskCA13","athabaskCA16","athabaskCA24","athabaskCA26","athabaskCA6","athabaskCA85","athabaskCA93"),
Chilcotin=c("athabaskCN15","athabaskCN27","athabaskCN36","athabaskCN40","athabaskCN42","athabaskCN9"),
Slavey=c("athabaskSV3","athabaskSV6")
)
for(i in names(popList)){
    if(i%in%c("misc","Carrier","Chilcotin","Slavey"))
        next
    keep<-popInfo[,3]%in%popList[[i]]
    if(sum(keep)!=0)
    mergeList[[i]]<-popInfo[keep,1]
}
names(mergeList)<-paste0("Merge_",names(mergeList))


#step 2 read the column of the population information

#
s<-snpMatrix::col.summary(pl$pl)
table(s$MAF>0)
range(s$Call.rate)
r<-snpMatrix::row.summary(pl$pl)

##min call rate<-0.2

keepInd <- r$Call.rate > 0.01
ind<-rownames(pl$pl)[keepInd]
pop<-popInfo[ind,3]
popInfo<-popInfo[ind,]

##
freqAll<-colMeans(pl$geno,na.rm=T)/2
keep<-freqAll>0.01 & freqAll<0.99 
geno<-pl$geno[keepInd,keep]
rownames(geno) <-  ind
sapply(mergeList,function(x) x[!(x%in%ind)])

pos<-pl$bim[keep,]
pos$block<-paste(pos[,1],cut(pos[,4],seq(1,3e8,by=5e6)))

siteInfo<-data.frame(block=pos$block,type=paste(pos[,5],pos[,6],sep=""))
ord<-order(siteInfo$block)

pos<-pos[ord,]
geno<-geno[,ord]
snp<-snp[ord]

siteInfo<-data.frame(block=pos$block,type=paste(pos[,5],pos[,6],sep=""))

popNam<-unique(pop)
popNamEx<-names(mergeList)
freq<-multicore::mclapply(popNam,function(x) colMeans(geno[pop==x,,drop=FALSE],na.rm=T)/2)
freqEx<-multicore::mclapply(popNamEx,function(x) colMeans(geno[rownames(geno)%in%mergeList[[x]],,drop=FALSE],na.rm=T)/2)

freq<-do.call(cbind,freq)
freqEx<-do.call(cbind,freqEx)
colnames(freq)<-popNam
colnames(freqEx)<-popNamEx
freq<-cbind(freq,freqEx)


len<-multicore::mclapply(popNam,function(x) colSums(!is.na(geno[pop==x,,drop=FALSE])))
len<-do.call(cbind,len)
colnames(len)<-popNam
lenEx<-multicore::mclapply(popNamEx,function(x) colSums(!is.na(geno[rownames(geno)%in%mergeList[[x]],,drop=FALSE])))
lenEx<-do.call(cbind,lenEx)
colnames(lenEx)<-popNamEx
len<-cbind(len,lenEx)
Nind<-apply(len,2,max)

rownames(pos)<-paste(pos[,1],pos[,4])
rownames(siteInfo)<-rownames(pos)
rownames(freq)<-rownames(pos) 
rownames(len)<-rownames(pos)









nHap<-as.integer(len)*2
dim(nHap)<-dim(freq)
colnames(nHap)<-colnames(freq)
rownames(nHap)<-rownames(freq)
popNames<-colnames(freq)

save(nHap,file="data/dataLen.Rdata")
write(colnames(freq),file="data/pops.txt")
save(siteInfo,freq,Nind,file="data/data.Rdata")

gg<-as.vector(geno)
 
con<-file("data/geno.bin","wb")
writeBin(gg,con)
close(con)

if(FALSE){
    con<-file("data/geno.bin","rb")
    g2<-readBin(con,what="integer",n=1e9)
    close(con)
    dim(g2)<-c(length(g2)/nrow(freq),nrow(freq))
}

save(snp,ind,popInfo,file="data/genoInfo.Rdata")



  

