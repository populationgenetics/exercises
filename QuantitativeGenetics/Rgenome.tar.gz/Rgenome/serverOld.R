
actionFgenome<-0
actionRgenome<-0
calculate.a.IBD<-function(F,phi=0.013){
  
    ma<-1-log(F)/log(2)
    mb=0
  

    m<-ma+mb
    a<--m*log(1-phi)
#cat("m=",m," ma=",ma," mb=",mb," a=",a," k0=",k0," k1=",k1," k2=",k2,"\n")
  return(a)
}


source("http://popgen.dk/albrecht/open/online.R")
 source("/pontus/data/anders/misc/relateTest/Relate/Relate/R/sim_chr.R")
library(shiny)
chrLen <-read.table("/pontus/genomes/refgenomes/hg19/merged/hg19NoChr.fa.fai",as.is=T)[1:22,]
chrLen <- chrLen[order(as.integer(chrLen[,1])),]


##source("/home/albrecht/df3/df3Fun.R")
#source("/home/albrecht/Rfun/treeMix.R")
#library(fastmatch,lib.loc="/home/albrecht/R/x86_64-pc-linux-gnu-library/3.0")
#source("/home/albrecht/Rfun/NGSpca.R")
source("/home/albrecht/Rfun/shiny.R")

#########################################3
 
######################################################################
#      Shiny stuff
#      only the stuff above should be modified
#
##############################################################

        
calculate.a<-function(k0,k1,k2,phi=0.013){
  if(k2==0){
    ma<-1-log(k1)/log(2)
    mb=0
  }
  else{
    xa<-(k1+2*k2+sqrt((k1+2*k2)^2-4*k2))/2
    xb<-k2/xa
    ma<-1-log(xa)/log(2)
    mb<-1-log(xb)/log(2)
  }
  m<-ma+mb
  a<--m*log(1-phi)
#cat("m=",m," ma=",ma," mb=",mb," a=",a," k0=",k0," k1=",k1," k2=",k2,"\n")
  return(a)
}


   
  
shinyServer(function(input, output) {

   
    
############################################################
##           
############################################################

    output$errPlot <- reactivePlot(function() {

        if(pw(input,passWord))
            return()
        
        ind<-input$chooseInd
        
        if(length(ind)==actionFgenome){
            errorPlot("choose individuals")
            return()
        }
        
        colorAnd(input$color)
        
        el<-errList
        if(input$qual=="Q20q30")
            el<-errListQ
        mat<-do.call(rbind,lapply(el[ind],function(x) x$typeErr))
        over<-do.call(rbind,lapply(el[ind],function(x) x$overallErr))
        
        res<-cbind(mat,over/100)
        names(res)[13]<-"overall"
        write.table(res,file="/home/albrecht/public/albrecht/shiny/tmp/tmp.dat")

        if(input$pdf)
            pdf("/home/albrecht/public/albrecht/shiny/tmp/tmp.pdf",he=input$h,w=input$w)
        
        
        
        if(input$leg)
            barplot(mat,beside=T,col=1:nrow(mat),legend=paste(ind,round(over,2),"%"),args.legend=list(x="top",bty="n"),ylab="Error rates",xlab="Error types")
        else
            barplot(mat,beside=T,col=1:nrow(mat),ylab="Error rates",xlab="Error types")
      
        if(input$pdf){
            dev.off()
            plot(0:1,0:1,col="transparent",main="pdf: http://popgen.dk/albrecht/open/tmp/tmp.pdf? ")
        }

        
    })
#########################3
    output$bamFiles <- reactiveTable(function() {
        if(pw(input,passWord,type="text"))
            return()
        
        ind<-input$chooseInd
        
        if(length(ind)==0){
            mat<-matrix("choose individuals",1,1)
            return(mat)
        }
        bn<-bamNam
        names(bn)<-noNamesNames
        #names(noNames)
        #names(bn)<-sub(" ","",names(bn))
        mat <-cbind(ind,bamFile=bn[ind])
        rownames(mat)<-NULL
        return(mat)

    }) 
#######################################
    output$downloadData <- downloadHandler( 
        filename = function() { 'out.txt' },
        content = function(file) {
            dat<-read.table("/home/albrecht/public/albrecht/shiny/tmp/tmp.dat")
            write.table(dat, file,sep="\t")
        }
        )

################# moment F
    output$momentF <- reactiveTable(function() {


        f<-input$f
        aa <- input$aa
        Aa <- input$Aa
        AA <- input$AA
        if(any(is.na(c(f,aa,Aa,AA)))){
            mat <- matrix("Fill in aa,Aa,AA and frequency",1,1)
            return(mat)
        }
        N<-aa+Aa+AA
        Eaa <- f^2*N
        EAa <- f*(1-f)*2*N
        EAA <- (1-f)^2*N
        F <- (EAa - Aa)/EAa
        mat <- matrix(c(aa,Aa,AA,Eaa,EAa,EAA,F),nrow=1)
        colnames(mat) <- c("aa","Aa","AA","Eaa","EAa","EAA","F")
        rownames(mat)<-"moment"
        return(mat)

        
    })
############################# sim F genomes
     output$simRgenome <- reactivePlot(function() {

         
         if (input$runFgenome[1] <= 0 | is.null(input$runFgenome)){
             errorPlot("press run simulation")
             return()
         }

         
         isolate({
             
             phi<-0.013
             snp=1000
             k0 <- input$k0
             k1 <- input$k1
             k2 <- input$k2
             k<-c(k0,k1,k2)
             if (sum(k)!=1){
                 errorPlot("The relationshipt coefficients must sum to one")
                 return()
             }
    
             a <- input$a
             if(a<=0|is.na(a)){
                 if(k0>1-0.000000001)
                     a<-0.04
                 else
                     a<-calculate.a(k0,k1,k2,phi=phi)

             }
             if(is.nan(a))
                 validate(  need(FALSE, "Impossible relationship chosen")  )

             len <- 200 # MB
             fun<-function(x)
                 s<- sim_chr(snp,freq=0.2, min=0.5, max=0.95, k=k, a=a, number_per_cm=snp/x/(phi*100) )
             ss <- lapply(chrLen[,2]/1e6,fun)
             pos <- unlist(sapply(ss,function(x)x$pos))/(100*phi)
             state <- unlist(sapply(ss,function(x)x$state))+1
             chrl <- unlist(sapply(ss,function(x)length(x$state)))
             chr <- rep(1:22,chrl)
             ccol <- c("darkgreen","darkred","darkblue")
             plot(pos/1e6,chr,col=ccol[state],ylab="chromosomes",xlab="positions (Mb)",pch="|",axes=F,main=paste("Relatedness for this pair of individuals is",paste(c("k0=","K1=","K2="), round(table(factor(state,levels=1:3))/length(state),3),collapse=" ")))
             axis(1)
             text(1:2,1:2)
             legend("topright",fill=ccol,c("IBD=0","IBD=1","IBD=2"))
             text(rep(-10,22),1:22,1:22,xpd=T)

         #    actionFgenome<<-actionFgenome+1  
         })
       
    }) 
###############
}) 
